//Sofia De Palma section 1 
import java.util.Scanner;
public class Driver{
    public static void main(String[] args){
      Scanner scan = new Scanner(System.in);
      
      //player1
      System.out.println("Please enter a a name for player 1: ");
      String player1Name = scan.nextLine();
      Player player1 = new Player(player1Name);
      
      //player2
      System.out.println("Please enter a a name for player 2: ");
      String player2Name = scan.nextLine();
      Player player2 = new Player(player2Name);
      
      //player cards
      Card card1 = null;
      Card card2 = null;
      Deck tableDeck = new Deck(54); // Temporary deck to hold cards on the table

      Deck deck = new Deck();
      for(int s = 0; s <= 3; s++){
        deck.shuffle();

      }
      for(int i = 0; i < 27; i++){
        player1.getPlayerDeck().addToDeck(deck.dealCard(2 * i));
        player2.getPlayerDeck().addToDeck(deck.dealCard(2 * i + 1));
      }

      System.out.println(player1.getName() + " has " + player1.getPlayerDeck().getNumCards() + " cards" );
      System.out.println(player2.getName() + " has " + player2.getPlayerDeck().getNumCards() + " cards" );

      while (player1.getPlayerDeck().getNumCards() > 0 && player2.getPlayerDeck().getNumCards() > 0) {
        System.out.println("Press Enter to deal card");
        String enter1 = scan.nextLine();
        if(enter1.isEmpty()){
          card1 = player1.getPlayerDeck().dealCard();
          System.out.println(player1.getName() + "'s card is " + card1 + '\n');
          tableDeck.addToDeck(card1);
        }
        System.out.println("Press Enter to deal card");
        String enter2 = scan.nextLine();
        if(enter2.isEmpty()){
          card2 = player2.getPlayerDeck().dealCard();
          System.out.println(player2.getName() + "'s card is " +  card2 + '\n');
          tableDeck.addToDeck(card2);
        }
        if(card1.getValue() > card2.getValue()){
          player1.getPlayerDeck().transferCardsFrom(tableDeck);
          System.out.println(player1.getName() + " got the cards");
          System.out.println(player1.getName() + " has " + player1.getPlayerDeck().getNumCards() + " cards");
          System.out.println(player2.getName() + " has " + player2.getPlayerDeck().getNumCards() + " cards");
        }
        else if(card2.getValue() > card1.getValue()){
          player2.getPlayerDeck().transferCardsFrom(tableDeck);
          System.out.println(player2.getName() + " got the cards");
          System.out.println(player1.getName() + " has " + player1.getPlayerDeck().getNumCards() + " cards");
          System.out.println(player2.getName() + " has " + player2.getPlayerDeck().getNumCards() + " cards");
        }
        else {
          System.out.println("It's a tie! Cards remain on the table.");
          System.out.println(player1.getName() + " has " + player1.getPlayerDeck().getNumCards() + " cards");
          System.out.println(player2.getName() + " has " + player2.getPlayerDeck().getNumCards() + " cards");
        }
      }

      if (player1.getPlayerDeck().getNumCards() == 0) {
        System.out.println(player2.getName() + " wins the game!");
    } else if (player2.getPlayerDeck().getNumCards() == 0) {
        System.out.println(player1.getName() + " wins the game!");
    }
      scan.close();
    }
}