//Aaron Hossain section 1 
public class Joker extends Card {

    public Joker(int value) {
        super(value, 14);
    }

    public String getSuitAsString() {
        return "Joker";
    }

    public String getValueAsString() {
        return "Joker";
    }

    public String toString() {
        return "Joker";
    }
}