//Sofia De Palma section 1 
public class Player{
    private String name;
    private Deck playerDeck;

    public Player(String name){
        this.name = name;
        this.playerDeck = new Deck(54);
    }

    public String getName(){
        return name;
    }
    
    public Deck getPlayerDeck(){
        return playerDeck;
    }
}